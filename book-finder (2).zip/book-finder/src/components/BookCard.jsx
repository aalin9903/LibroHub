import React from "react";
import "./BookCard.css";

const BookCard = ({ book, onClick }) => {
  const coverUrl = book.cover_i
    ? `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`
    : "https://via.placeholder.com/150x220?text=No+Cover";

  return (
    <div className="book-card" onClick={onClick}>
      <img src={coverUrl} alt={book.title} className="book-cover" />
      <div className="book-info">
        <h2 className="book-title">{book.title}</h2>
        <p className="book-author">
          {book.author_name ? book.author_name[0] : "Unknown Author"}
        </p>
      </div>
    </div>
  );
};

export default BookCard;


