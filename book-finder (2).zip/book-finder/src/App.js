import React, { useState, useEffect } from "react";
import BookCard from "./components/BookCard";
import "./App.css";

function App() {
  const [query, setQuery] = useState("");
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [animateBooks, setAnimateBooks] = useState(false);

 
  const [placeholder, setPlaceholder] = useState("");
  const phrases = [
    "Search the world of words 🌍",
    
  ];

 
  const [selectedBook, setSelectedBook] = useState(null);
  const [bookDetails, setBookDetails] = useState(null);

  useEffect(() => {
    let index = 0;
    let charIndex = 0;
    let deleting = false;

    const typingEffect = () => {
      const currentPhrase = phrases[index];
      if (!deleting) {
        setPlaceholder(currentPhrase.substring(0, charIndex + 1));
        charIndex++;
        if (charIndex === currentPhrase.length) {
          deleting = true;
          setTimeout(typingEffect, 1500);
          return;
        }
      } else {
        setPlaceholder(currentPhrase.substring(0, charIndex - 1));
        charIndex--;
        if (charIndex === 0) {
          deleting = false;
          index = (index + 1) % phrases.length;
        }
      }
      setTimeout(typingEffect, deleting ? 50 : 120);
    };

    typingEffect();
  }, []);

  const searchBooks = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setError("");
    setBooks([]);
    setAnimateBooks(false);

    try {
      const res = await fetch(
        `https://openlibrary.org/search.json?title=${encodeURIComponent(query)}`
      );
      const data = await res.json();
      if (!data.docs || data.docs.length === 0) {
        setError("No books found. Try a different title!");
      } else {
        setBooks(data.docs.slice(0, 12));
        setTimeout(() => setAnimateBooks(true), 200);
      }
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") searchBooks();
  };

  // Fetch full book details when user clicks a book
  const openBookDetails = async (book) => {
    setSelectedBook(book);
    setBookDetails(null);
    try {
      const res = await fetch(`https://openlibrary.org${book.key}.json`);
      const data = await res.json();
      setBookDetails(data);
    } catch {
      setBookDetails({ error: "Unable to fetch details" });
    }
  };

  const closeModal = () => {
    setSelectedBook(null);
    setBookDetails(null);
  };

  return (
    <div className="app-container">
      <header className="header">
        <h1 className="app-title">📚 LibroHub</h1>
        <p className="subtitle">
          Search your favorite books instantly !
        </p>
      </header>

      <div className="search-section">
        <div className="search-box">
          <input
            type="text"
            placeholder={placeholder || "Search the world of words 🌍"}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <button onClick={searchBooks}>Search</button>
        </div>
      </div>

      {loading && <p className="info">Loading books...</p>}
      {error && <p className="error">{error}</p>}

      {!loading && !error && books.length === 0 && (
        <div className="empty-state">
          <img
            src="https://cdn-icons-png.flaticon.com/512/4072/4072868.png"
            alt="empty"
          />
          <p>Explore knowledge, stories, and more 📖</p>
        </div>
      )}

      <div className={`book-list ${animateBooks ? "fade-in" : ""}`}>
        {books.map((book, index) => (
          <BookCard
            key={index}
            book={book}
            onClick={() => openBookDetails(book)}
          />
        ))}
      </div>

      {/* Modal for book details */}
      {selectedBook && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={closeModal}>✖</button>

            <img
              src={
                selectedBook.cover_i
                  ? `https://covers.openlibrary.org/b/id/${selectedBook.cover_i}-L.jpg`
                  : "https://via.placeholder.com/150x220?text=No+Cover"
              }
              alt={selectedBook.title}
              className="modal-cover"
            />

            <h2 className="modal-title">{selectedBook.title}</h2>
            <p className="modal-info">
              <strong>Author:</strong>{" "}
              {selectedBook.author_name ? selectedBook.author_name[0] : "Unknown"}
            </p>
            <p className="modal-info">
              <strong>Published:</strong>{" "}
              {selectedBook.first_publish_year || "N/A"}
            </p>
            {selectedBook.publisher && (
              <p className="modal-info">
                <strong>Publisher:</strong> {selectedBook.publisher[0]}
              </p>
            )}

            {bookDetails ? (
              bookDetails.description ? (
                <p className="modal-desc">
                  <strong>Description:</strong>{" "}
                  {typeof bookDetails.description === "string"
                    ? bookDetails.description
                    : bookDetails.description.value}
                </p>
              ) : (
                <p className="modal-desc">
                  <strong>Description:</strong> Not available.
                </p>
              )
            ) : (
              <p className="modal-desc">Loading description...</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
